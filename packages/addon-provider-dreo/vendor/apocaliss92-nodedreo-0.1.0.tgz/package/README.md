# nodedreo

Node.js / TypeScript client for **Dreo smart devices** over the Dreo cloud (REST + WebSocket).

Spiritual successor to [pydreo](https://github.com/JeffSteinbok/pydreo) — same wire protocol, same cloud endpoints, TypeScript-native. If you can control your device in the Dreo mobile app, you can control it with this library.

> **Node only.** The cloud transport uses `ws` (native WebSocket) and crypto primitives available in Node ≥ 20. It does not run in browsers.

---

## Install

```bash
npm i @apocaliss92/nodedreo
```

**Requires Node 20 or later.**

---

## Quick start

```ts
import { Nodedreo } from '@apocaliss92/nodedreo';

const dreo = new Nodedreo({ email: 'you@example.com', password: 'secret' });

// 1. Authenticate
await dreo.login();

// 2. Discover devices registered to your account
const devices = await dreo.discoverDevices();

// 3. Open the WebSocket channel
await dreo.connect();

// 4. Create a typed device handle
import type { FanDevice } from '@apocaliss92/nodedreo';
const fan = await dreo.createDevice(devices[0]) as FanDevice;

// 5. Listen for real-time state updates
fan.on('stateChanged', ({ changed }) => {
  console.log('state changed:', changed);
});

// 6. Send commands
fan.setPower(true);
fan.setSpeed(3);
fan.setOscillate(true);

// 7. Clean up when done
dreo.close();
```

### Token-based authentication

If you already have an access token (e.g. captured from another session):

```ts
const dreo = new Nodedreo({ token: 'your-token', region: 'us' });
// skip login() — go straight to discoverDevices() / connect()
await dreo.discoverDevices();
```

---

## Supported devices

| Device class | Series | Status |
|---|---|---|
| `TowerFanDevice` | DR-HPF tower fans | Verified |
| `AirCirculatorDevice` | DR-HAF air circulators | Verified |
| `FanDevice` | Generic fan base | Verified |
| `HeaterDevice` | DR-HSH heaters | `@experimental` |
| `AcDevice` | DR-HAC portable ACs | `@experimental` |
| `HumidifierDevice` | DR-HHM humidifiers | `@experimental` |
| `DehumidifierDevice` | DR-HDehumidifier series | `@experimental` |
| `AirPurifierDevice` | DR-HAP air purifiers | `@experimental` |
| `CeilingFanDevice` | DR-HCF ceiling fans | `@experimental` |
| `EvaporativeCoolerDevice` | DR-HEC evaporative coolers | `@experimental` |
| `ChefMakerDevice` | DR-KCM chef maker | `@experimental` |
| `UnknownDevice` | Any unrecognised model | Fallback (state passthrough) |

`@experimental` — the wire keys and state shape are transcribed from pydreo and community captures, but have not been verified against real hardware. Open an issue if something is wrong.

---

## How it works

1. **REST** — `login()` posts credentials to the Dreo cloud API and gets an access token + region.  
2. **REST** — `discoverDevices()` fetches the list of devices on your account.  
3. **WebSocket** — `connect()` opens a persistent WebSocket to the Dreo message broker.  
4. **State** — `createDevice()` fetches the current device state over REST, then listens for live updates pushed over the WebSocket.  
5. **Commands** — `setX()` methods send a control message over the WebSocket and optimistically update local state.

All internals (`DreoHttp`, `DreoWs`, `hashPassword`, `login`, `createFetchHttp`) are kept out of the public surface to preserve API stability.

---

## API reference

### `Nodedreo`

```ts
new Nodedreo(
  creds: { email: string; password: string } | { token: string; region: string },
  opts?: { region?: string },
)
```

| Method | Returns | Description |
|---|---|---|
| `login()` | `Promise<void>` | Authenticate with the Dreo cloud |
| `discoverDevices()` | `Promise<DreoDeviceInfo[]>` | List devices on the account |
| `connect()` | `Promise<void>` | Open the WebSocket channel |
| `createDevice(info)` | `Promise<BaseDevice>` | Create a typed device handle and fetch initial state |
| `close()` | `void` | Disconnect the WebSocket |

### `BaseDevice` / `FanDevice`

All device classes extend `BaseDevice` (which is a typed event emitter).

**Events**

| Event | Payload | Description |
|---|---|---|
| `stateChanged` | `{ changed: Record<string, unknown> }` | Fired whenever one or more state keys change |

**`BaseDevice` properties**

| Property | Type | Description |
|---|---|---|
| `sn` | `string` | Device serial number |
| `model` | `string` | Model string from the cloud |
| `name` | `string` | Friendly name |
| `type` | `string` | Device type resolved from model |
| `state` | `Readonly<DeviceState>` | Current state snapshot |

**`FanDevice` properties + methods**

| Member | Type | Description |
|---|---|---|
| `power` | `boolean` | Current power state |
| `speed` | `number` | Current wind level |
| `oscillate` | `boolean` | Oscillation on/off |
| `mode` | `number \| string \| undefined` | Wind mode |
| `windType` | `number \| string \| undefined` | Wind type |
| `temperature` | `number \| undefined` | Ambient temperature reading |
| `setPower(on)` | `void` | Turn on/off |
| `setSpeed(n)` | `void` | Set wind level |
| `setOscillate(on)` | `void` | Toggle oscillation |
| `setMode(m)` | `void` | Set wind mode |
| `setWindType(t)` | `void` | Set wind type |

**`AirCirculatorDevice`** adds:

| Member | Description |
|---|---|
| `hOscillate` | Horizontal oscillation state |
| `vOscillate` | Vertical oscillation state |
| `setHorizontalOscillate(on)` | Toggle horizontal oscillation |
| `setVerticalOscillate(on)` | Toggle vertical oscillation |

**`FAN_KEYS`** — raw wire key constants (`poweron`, `windlevel`, `oscon`, `mode`, `windtype`, `temperature`, `hoscon`, `voscon`). Useful when working directly with `device.state` or writing tests.

---

## Diagnostics dumper

```ts
import { createDumper } from '@apocaliss92/nodedreo';

const dumper = createDumper(fan, { redact: true }); // redact: true by default
const snapshot = dumper.dump();
// { sn: '****1234', model: 'DR-HPF001S', type: 'towerFan', state: { poweron: true, windlevel: 3 } }

console.log(JSON.stringify(snapshot, null, 2));
```

`redact: true` masks all but the last 4 characters of the serial number before logging. Useful for sharing debug dumps without exposing account identifiers.

---

## Not yet verified against hardware

The following behaviours are assumed from pydreo reverse-engineering and community captures but have **not** been confirmed against a real Dreo account / device:

- **Device-list / state JSON shapes** — the library assumes `data.list[]` with `deviceSn` for device discovery and `data.mixed` for state; defensive fallbacks are in place but the exact field names may differ.
- **Fan boolean encodings** — oscillation and power fields are treated as booleans (`true`/`false`); some models may use `0`/`1` integers on the wire.
- **WebSocket keepalive payload** — the library currently sends the literal string `'ping'` on a timer; the actual protocol may expect a JSON keepalive or a WebSocket-level ping frame.

Run `npm run test:e2e:live` (requires a `.env` file with real credentials) to validate these assumptions against your own account.

---

## Error types

| Class | Thrown when |
|---|---|
| `DreoError` | Base class for all library errors |
| `DreoAuthError` | Login / token failure |
| `DreoApiError` | Unexpected HTTP response from the cloud API |
| `DreoTransportError` | HTTP transport failure (network error reaching the REST API) |
| `DreoDeviceOfflineError` | Reserved — not yet thrown (planned: commands to a known-offline device) |

---

## License

MIT — see [LICENSE](./LICENSE).
