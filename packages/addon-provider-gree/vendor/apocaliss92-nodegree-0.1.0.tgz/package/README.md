# nodegree

A Node.js library for controlling Gree/Sinclair/Cooper&Hunter climate devices over UDP.

`nodegree` mirrors the feature scope of `greeclimate` (the popular Python library) while exposing a clean, promise-based TypeScript API and staying close to the wire: automatic V1/V2 AES encryption negotiation, per-MAC request serialisation, and a diagnostics dumper — all without any native bindings.

## Install

```bash
npm install @apocaliss92/nodegree
```

Requires **Node.js 20+**. The library uses the built-in `node:dgram` module and is **not** compatible with browser environments.

## Quick start

```ts
import { Nodegree, HvacMode } from '@apocaliss92/nodegree';

// 1. Create the facade
const gree = new Nodegree({ timeoutMs: 3000 });

// 2. Discover devices on the local network
const found = await gree.discover({ timeoutMs: 2000 });
console.log(found);
// [{ ip: '192.168.1.42', port: 7000, mac: 'AABBCCDDEEFF', name: 'Living Room' }]

// 3. Bind and control an AC
const ac = await gree.createAc({ ip: found[0].ip, mac: found[0].mac });

// 4. Read current state
await ac.updateState();
console.log('Power:', ac.power, '| Temp:', ac.targetTemperature, '°C');

// 5. Change settings
await ac.setPower(true);
await ac.setTargetTemperature(23);
await ac.setMode(HvacMode.Cool);

// 6. Poll for changes
ac.on('stateChanged', ({ changed }) => {
  console.log('State changed:', changed);
});
ac.startPolling(30_000); // every 30 s

// 7. Clean up
await gree.close();
```

## Supported features

| Feature | Details |
|---|---|
| **HVAC modes** | Auto, Cool, Dry, Fan, Heat |
| **Fan speed** | Auto, Low, Medium-Low, Medium, Medium-High, High |
| **Vertical swing** | 12 positions (full swing → fixed lower) |
| **Horizontal swing** | 7 positions (full swing → right) |
| **Temperature** | Celsius & Fahrenheit; clamped per protocol limits |
| **Presets** | Turbo, Quiet, Sleep, PowerSave, SteadyHeat |
| **Extras** | Light, XFan, Health, FreshAir |
| **Polling** | `startPolling(intervalMs)` / `stopPolling()` |
| **Events** | `stateChanged`, `error`, `offline` |

## Encryption

Gree devices use either AES-128-ECB (V1) or AES-128-GCM (V2). By default `nodegree` tries V2 first and falls back to V1 automatically during the bind handshake. You can force a specific version:

```ts
const gree = new Nodegree({ encryption: 'v1' }); // or 'v2' | 'auto' (default)
```

> Newer firmware (e.g. `V3.4.M`) answers the plaintext discovery scan with an **ECB**-encrypted payload but performs the bind and all subsequent commands over **GCM** — `'auto'` handles this transparently. These devices also echo their MAC in the response `cid` field (with `tcid: "app"`), which `nodegree` correlates correctly.

## Tested against real hardware

Discovery, bind, full state decode, and the command (write) path are validated end-to-end against physical Gree units (firmware `V3.4.M`). A manual live runner is included:

```bash
npm run build
node scripts/e2e-live.mjs 192.168.1.255   # directed broadcast for your subnet
```

It discovers every device on the segment, binds, and prints the decoded state for each. The library is local-only (UDP `node:dgram`) and never contacts the cloud.

## API reference

### `Nodegree`

```ts
new Nodegree(options?: NodegreeOptions, deps?: NodegreeDeps)
```

| Option | Type | Default | Description |
|---|---|---|---|
| `timeoutMs` | `number` | `3000` | UDP request timeout |
| `retries` | `number` | `3` | Retry count per request |
| `encryption` | `'auto' \| 'v1' \| 'v2'` | `'auto'` | Cipher version |

**Methods**

| Method | Returns | Description |
|---|---|---|
| `discover(opts?)` | `Promise<DiscoveredDevice[]>` | Broadcast scan; `opts.timeoutMs` controls wait window |
| `createAc(target)` | `Promise<AcDevice>` | Bind and return a ready-to-use AC device |
| `close()` | `Promise<void>` | Close the underlying UDP socket |

### `AcDevice`

Extends `BaseDevice` (which extends `EventEmitter`).

**Getters**

| Property | Type | Description |
|---|---|---|
| `power` | `boolean` | On/off |
| `mode` | `HvacMode` | Current HVAC mode |
| `fanSpeed` | `FanSpeed` | Fan speed |
| `targetTemperature` | `number` | Set-point (device unit) |
| `currentTemperature` | `number \| undefined` | Sensor reading in °C |
| `swingVertical` | `VerticalSwing` | Vertical louver position |
| `swingHorizontal` | `HorizontalSwing` | Horizontal louver position |
| `light` | `boolean` | Panel light |
| `xfan` | `boolean` | XFan (moisture removal) |
| `health` | `boolean` | Health/plasma mode |
| `freshAir` | `boolean` | Fresh-air intake |
| `turbo` | `boolean` | Turbo preset |
| `quiet` | `boolean` | Quiet preset |
| `sleep` | `boolean` | Sleep preset |
| `powerSave` | `boolean` | PowerSave preset |
| `steadyHeat` | `boolean` | SteadyHeat preset |

**Setters** — each returns `Promise<void>`

`setPower`, `setMode`, `setFanSpeed`, `setTargetTemperature`, `setSwingVertical`, `setSwingHorizontal`, `setLight`, `setXfan`, `setHealth`, `setFreshAir`, `setTurbo`, `setQuiet`, `setSleep`, `setPowerSave`, `setSteadyHeat`

**Events** (via `.on(event, listener)`)

| Event | Payload | Fired when |
|---|---|---|
| `stateChanged` | `{ changed: Record<string, number> }` | Any property changes after `updateState` or `setState` |
| `error` | `Error` | A poll cycle fails |
| `offline` | — | A timeout or offline error is detected during polling |

**Polling**

```ts
ac.startPolling(30_000); // start; fires an immediate poll then repeats
ac.stopPolling();         // stop
ac.polling;               // boolean — whether polling is active
```

### Enums

```ts
import {
  HvacMode, FanSpeed, HorizontalSwing, VerticalSwing, TempUnit,
} from '@apocaliss92/nodegree';
```

### Error classes

| Class | Extends | Thrown when |
|---|---|---|
| `GreeError` | `Error` | Base class for all library errors |
| `GreeAuthError` | `GreeError` | Bind failed or device not bound |
| `GreeTimeoutError` | `GreeError` | UDP request timed out |
| `GreeDeviceOfflineError` | `GreeError` | Device unreachable |
| `GreeTransportError` | `GreeError` | Transport-level failure |

## Diagnostics

The `createDumper` helper snapshots device state for bug reports, redacting the MAC address by default:

```ts
import { createDumper } from '@apocaliss92/nodegree';

const dumper = createDumper(ac, { redact: true });
const dump = await dumper.dump();
console.log(JSON.stringify(dump, null, 2));
// { mac: '********EEFF', state: { Pow: 1, Mod: 1, ... }, capabilities: { ... } }
```

## Node.js only

`nodegree` depends on `node:dgram` (UDP sockets). It does not work in browsers or Deno. If you need to inject a custom socket (e.g. for testing), pass `deps.createSocket` to the `Nodegree` constructor.

## License

MIT
