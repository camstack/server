import { describe, it, expect } from "vitest";
import { WyzeDTLSConn } from "../src/tutk/dtls/WyzeDTLSConn.js";

// The 16-bit sequence fields on the wire are counters that wrap. Left unbounded,
// the periodic ACK ticker (every 100 ms) reaches 65536 in ~1h49m and
// `writeUInt16LE` throws ERR_OUT_OF_RANGE — an uncaught exception inside a
// timer, which killed the whole provider runner five times a day.
function makeConn(): any {
  const c: any = new WyzeDTLSConn({
    host: "192.168.1.50",
    uid: "ABCD1234WXYZ",
    enr: "0123456789ABCDEF0123456789ABCDEF",
    mac: "AABBCCDDEEFF",
    model: "WYZE_CAKP2JFUS",
  });
  c.sid = Buffer.from([1, 2, 3, 4, 5, 6, 7, 8]);
  return c;
}

describe("16-bit wire sequence counters wrap instead of overflowing", () => {
  it("msgTxData wraps txSeq from 65535 to 0", () => {
    const c = makeConn();
    c.txSeq = 65535;
    const payload = Buffer.from([0xaa]);
    expect(c.msgTxData(payload, 0).readUInt16LE(6)).toBe(65535);
    expect(() => c.msgTxData(payload, 0)).not.toThrow();
    expect(c.msgTxData(payload, 0).readUInt16LE(6)).toBe(1);
  });

  it("msgIOCtrl wraps the 16-bit seqCmd field and keeps the 32-bit copy", () => {
    const c = makeConn();
    c.seqCmd = 65535;
    const first = c.msgIOCtrl(Buffer.from([0x01]));
    expect(first.readUInt16LE(18)).toBe(65535);
    expect(first.readUInt32LE(28)).toBe(65535);
    let next: Buffer | undefined;
    expect(() => { next = c.msgIOCtrl(Buffer.from([0x01])); }).not.toThrow();
    expect(next!.readUInt16LE(18)).toBe(0);
    expect(next!.readUInt32LE(28)).toBe(65536);
  });
});
